package edu.neu.csye6200;

public class Cart {

   private double myCash;
    double myTotal;
    double myChange;
    {
         this.myCash = 20;
         this.myTotal = 0;
         this.myChange = 0;
    }

    public Cart()
    {
         super();
    }

    public Cart(double myCash, double myTotal,double myChange)

    {
         super();
         this.myCash = myCash;
         this.myTotal = myTotal;
         this.myChange= myChange;
    }



    public double getMyCash() {
         return myCash;
    }

    public void setMyCash(double myCash) {
         this.myCash = myCash;
    }

    public double getMyTotal() {
         return myTotal;
    }

    public void setMyTotal(double myTotal) {
         this.myTotal = myTotal;
    }

    public double getMyChange() {
         return myChange;
    }
    public void setMyChange(double myChange){
         this.myChange = myChange;
    }

    public String toString()
    {
         StringBuilder sb = new StringBuilder();

         sb.append("\n\tCash:").append(this.myCash);
         sb.append("\n\tTotal:").append(this.myTotal);
         sb.append("\n\tChange:").append(this.myChange);
         return sb.toString();
        // return "Cart [myCash=" +myCash+",myTotal = " +myTotal+", myChange =" +myChange+"]";
    }



    public void sillyCheckout(double cash, double total, double price)
    {

         total = total + price;
         double change;
         change = cash - total;



    }

    public double checkout(Cart myCart, Item myItem) {


         myCart.myTotal=myCart.myTotal+myItem.getPrice();
         myCart.myChange= myCart.getMyCash()- myCart.getMyTotal();
         return myCart.getMyChange();



    }
    public static void demo()
    {
        // System.out.println("\n\t" + Cart.class.getName() + ".demo()...");

         Item milk = new Item(1,2,"Milk");
         Item Bread = new Item(2,3," Bread");
         Item eggs = new Item(3,8,"Eggs");

         System.out.println(milk);
         System.out.println(Bread);
         System.out.println(eggs);

         Cart myShoppingCart = new Cart();

         myShoppingCart.sillyCheckout(myShoppingCart.getMyCash(), myShoppingCart.getMyTotal(), milk.getPrice());
         myShoppingCart.sillyCheckout(myShoppingCart.getMyCash(), myShoppingCart.getMyTotal(),Bread.getPrice());
         myShoppingCart.sillyCheckout(myShoppingCart.getMyCash(), myShoppingCart.getMyTotal(), eggs.getPrice());

         myShoppingCart.checkout(myShoppingCart,milk);
         myShoppingCart.checkout(myShoppingCart,Bread);
         myShoppingCart.checkout(myShoppingCart,eggs);

         System.out.println("TOTAL:\t" + myShoppingCart.myTotal);
         System.out.println("CHANGE:\t" + myShoppingCart.myChange);
         System.out.println(myShoppingCart);
         System.out.println(myShoppingCart.toString());

         System.out.println("\n\t" + Cart.class.getName() + ".demo()...done!");
    }

    public double toString(double myTotal) {
         return myTotal;

    }

    // public boolean toString(double myTotal) {
   // }
}