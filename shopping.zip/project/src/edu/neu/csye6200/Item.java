package edu.neu.csye6200;

//public class Item {
	//private int id;
	//private double price;
	//private String name;
	

//}

public class Item {

	 private int id;
	 private String name;
	 private int price;

	    public double myCash;
	    public double myTotal;
	    private double myChange;

	    {
	        this.myCash = 20;
	        this.myTotal = 0;
	        this.myChange = 0;
	    }


	    public double checkout(Cart myCart, Item myItem) {


	        myCart.myTotal=myCart.myTotal+myItem.getPrice();
	        myCart.myChange= myCart.getMyCash()- myCart.getMyTotal();
	        return myCart.getMyChange();


	    }

	    public static void demo() {
	        Item milk = new Item(1, 2, "Whole Milk");
	        Item Bread = new Item(2, 3, "Whole wheat Bread");
	        Item eggs = new Item(3, 4, "Fresh Eggs");

	        Cart myShoppingCart = new Cart();
	        System.out.println("\nMilk:\t"+myShoppingCart.toString(milk.getPrice()));
	        System.out.println("\nBread:\t"+myShoppingCart.toString(Bread.getPrice()));
	        System.out.println("\nEggs:\t" +myShoppingCart.toString(eggs.getPrice()));


	        myShoppingCart.checkout(myShoppingCart,milk);
	        myShoppingCart.checkout(myShoppingCart,Bread);
	        myShoppingCart.checkout(myShoppingCart,eggs);

	       // System.out.println("MyTotal : \t" +myShoppingCart.toString(myShoppingCart.getMyTotal()));
	       // System.out.println("MyChange : \t" +myShoppingCart.toString(myShoppingCart.getMyChange()));

	        System.out.println("\nTOTAL:\t" + myShoppingCart.myTotal);
	        System.out.println("\nCHANGE:\t" + myShoppingCart.myChange);
	        //System.out.println(myShoppingCart);
	    }


	    public Item()
	    {
	        super();
	    }

	    public Item(int id, int price, String name)

	    {
	        super();
	        this.id = id;
	        this.price = price;
	        this.name= name;
	    }


	    public int getId() {
	        return id;
	    }

	    public void setId(int id) {
	        this.id = id;
	    }

	    public int getPrice() {
	        return price;
	    }

	    public void setPrice(int price) {
	        this.price = price;
	    }

	    public String getName() {
	        return name;
	    }
	    public void setName(String name) {
	        this.name = name;

	    }

	    public double getMyChange() {
	        return myChange;
	    }

	    public void setMyChange(double myChange) {
	        this.myChange = myChange;
	    }

	    public String toString()
	    {
	        return "Item [id=" +id+",name="+name+",price="+price+"]";
	    }



	}
